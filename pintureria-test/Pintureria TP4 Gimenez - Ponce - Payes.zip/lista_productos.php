<?php
// --- Configuración de la Base de Datos --- //
$servidor = "localhost";
$usuario = "root"; // Usuario por defecto de XAMPP/WAMP
$contrasena = ""; // Contraseña por defecto de XAMPP/WAMP
$basedatos = "pintureria";

// --- Conexión a la Base de Datos --- //
$conexion = new mysqli($servidor, $usuario, $contrasena, $basedatos);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// --- Lógica para Actualizar Productos --- //
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['editar_producto'])) {
    $idproducto = $_POST['idproducto'];
    $marcaDescripcion = $_POST['marcaDescripcion'];
    $precio = $_POST['precio'];
    // Nota: El campo 'stock' es simulado y no se actualiza en la BD
    // ya que no existe una columna para ello en el esquema proporcionado.

    $consulta_actualizar = "UPDATE productos SET marcaDescripcion = ?, precio = ? WHERE idproducto = ?";
    $sentencia = $conexion->prepare($consulta_actualizar);
    $sentencia->bind_param("sdi", $marcaDescripcion, $precio, $idproducto);
    
    if (!$sentencia->execute()) {
        echo "Error al actualizar el producto: " . $sentencia->error;
    }
    
    $sentencia->close();
    // Redireccionar para evitar reenvío del formulario al recargar
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// --- Consulta para Obtener los Productos --- //
$consulta_productos = "SELECT idproducto, marcaDescripcion, precio FROM productos ORDER BY idproducto";
$resultado = $conexion->query($consulta_productos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Stock de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        input[type="text"], input[type="number"] {
            width: calc(100% - 16px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            padding: 8px 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

    <h1>Gestión de Stock de Productos 🖌️</h1>

    <table>
        <thead>
            <tr>
                <th>Producto (Marca y Descripción)</th>
                <th>Precio ($)</th>
                <th>Cantidad en Stock (Simulado)</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($resultado && $resultado->num_rows > 0): ?>
                <?php while($producto = $resultado->fetch_assoc()): ?>
                    <?php
                        // Se genera una cantidad de stock aleatoria para la demostración
                        $stock_simulado = rand(5, 50);
                    ?>
                    <tr>
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="idproducto" value="<?php echo $producto['idproducto']; ?>">
                            <td><input type="text" name="marcaDescripcion" value="<?php echo htmlspecialchars($producto['marcaDescripcion']); ?>"></td>
                            <td><input type="number" step="0.01" name="precio" value="<?php echo htmlspecialchars($producto['precio']); ?>"></td>
                            <td><input type="number" name="stock" value="<?php echo $stock_simulado; ?>"></td>
                            <td><input type="submit" name="editar_producto" value="Editar"></td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4">No se encontraron productos en la base de datos.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
<?php
// --- Cerrar la conexión a la base de datos --- //
$conexion->close();
?>